package LearningJava;

public class ArraysOfStrings {
	
	public static void main (String[] args)
	{
		String [] words= new String[3];
		
		words[0]="hello";
		words[1]="to";
		words[2]="you";
		
		String[] fruits = {"apple","banana","kiwi"};
		
		for (String fruit:fruits)
		{
			System.out.println(fruit);
			
		}
		
		String text =null; 
		//non- primitive type. bunu yazinca aslinda hafiza sadece referance
		//yeri aliyor. default olarak bu null mus 
		
		System.out.println(text);
		
		String[] texts = new String[2];
		
		System.out.println(texts[0]);
		
		texts[0]="one";
		
		System.out.println(texts[0]);
		
		
		
		
		
	}
	

}
