package Casting;

class Machine{
	
	public void start(){
		System.out.println("Machine started...");
		
	}
	
	
}
class Camera extends Machine
{
	public void start(){
		System.out.println("Camera started...");
		
	}
	public void snap()
	{
		System.out.println("Photo taken...");
	}

}

public class App {
	
	public static void main(String[] args)
	{
		byte byteValue = 20;
		short shortValue = 55; 
		int intValue = 888;
		long longvalue = 12345;
		double doubleValue=23.3;
		
		
		System.out.println(Byte.MAX_VALUE);
		intValue =(int) longvalue;
		doubleValue =intValue;
		//System.out.println("Double value is "+doubleValue);
		//System.out.println("Int value is "+longvalue);
		
		byteValue = (byte)128;
		//System.out.println(byteValue);
		
		//////UPCASTING AND DOWNCASTING////////////////
		Machine mac1 = new Machine();
		Camera cam1 = new Camera();
		cam1.start();
		cam1.snap();
		//Upcasting 
		Machine mac2 = cam1; //upcasting-> hiyerarside yukari dogru gidiyorsun. 
		mac2.start();
		// mac2 icin snap cagiramazsin cunku bu onun icin tanimli degil . 
		//type of the variable determines what methods you can call. 
		//type of the object,that variable refers to determines which actual methods or implementations.
		
		//Downcasting: inheritly unsafed. 
		Machine mac3 = new Camera();
		Camera cam2 = (Camera) (mac3) ; //whem you downcosts java wants to confirm what you're doing
		cam2.snap();
		cam2.start();
		/* BUNU YAPAMAZSIN. RUN TIME ERROR. 
		Machine mac4= new Machine();
		Camera cam4= (Camera)mac4;
		cam4.start();
		cam4.snap();
		*/
		
		
		
		
	}

}
