package Serialization;

import java.io.Serializable;


public class Person implements Serializable{

	/**serialization:if you take an object you will serialize it, it means:turning that object
	 * kind of binary form,binsry data, 
	 * deseriailze: turning back into object// 
	 * serializable means 
	 * 
	 */
	private static final long serialVersionUID = 7050691575509059637L;
	private String name;
	private int id;
	private static int count;
	
	
	public Person(int id,String name) {
		this.id=id;
		this.name = name;
	}


	@Override
	public String toString() {
		return "Person [name=" + name + ", id=" + id + "]" + "tugce is gere";
	}


	public static void setCount(int i) {
		
		Person.count = count;
		
	}


	
	
	
}
