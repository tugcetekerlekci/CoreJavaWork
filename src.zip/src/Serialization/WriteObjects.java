package Serialization;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;

//classic interview question
//how do you make a class serializable in Java//
//implement Serializable class .

public class WriteObjects {
	
	public static void main(String[] args)
	{
		System.out.println("Writing objectsss... ");
		
		Person[] people = {new Person(123,"Sue"),new Person(12,"Mike"),new Person(1232,"Bob")};
		
		//Person mike = new Person(12,"Mike");
		//Person sue = new Person(123,"Sue");
		
		//System.out.println(mike);
		//System.out.println(sue);
		
		ArrayList <Person> peopleList = new ArrayList<Person>(Arrays.asList(people));
		
		try 
			(FileOutputStream fs = new FileOutputStream("people.bin"))
		{
			ObjectOutputStream os = new ObjectOutputStream(fs);
			
			os.writeObject(people);
			os.writeObject(peopleList);
			
			os.writeInt(peopleList.size());
			
			for(Person person: peopleList)
			{
				System.out.println(person);
			}
			
			
			
			//os.writeObject(mike);
			//os.writeObject(sue);
			
			
			
			
			
			os.close();
		
		} catch (FileNotFoundException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	

}
