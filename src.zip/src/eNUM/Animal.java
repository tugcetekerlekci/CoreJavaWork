package eNUM;

public enum Animal {
	
	
	
	CAT("kedi"),DOG("kopek"),MOUSE("fare");
	
	private String name;
	
	Animal(String name){
		
		this.name=name;
		
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String toString(){
			
		return "this animal is calleddd: " + name;
		
	}

}
