package Classes;

//Static key words
//instancee methods can not acces the static data. instance methods cannot touch the static data
//final JAVA's version of constant. 
// 
class Thing{
	
			public final static int LUCKY_NUMBER =7; 
			//you will no longer assign a value to it. 
			public String name; //instance variables: created for every seperate object,gets own copy. 
			public static String description; //class variables they're associated with the class. 
			
			public static int count = 0 ; 
			public int id = 0;
			
			public Thing()
			{
				count++; // count incremented everytime when the object is created. 
				id++;
				
			}
			
			public void showName()
			{
				System.out.println(name);
				
			}
			//static methods cant output instance variables, like name. 
			
			public static void showInfo()
			{
				System.out.println("Hello");
				//System.out.println(name); gives an error. because it is about particular object. 
			}
			
			
	
}

public class Static {
	
	public static void main(String[] args)
	
	{
			Thing.description = "I am description" ; 
			
			Thing.showInfo();

			System.out.println("Before creating objects count is "+Thing.count);
			
			
			Thing thing1 = new Thing();
			System.out.println("After creating objects first thing id is "+thing1.id);
			Thing thing2 = new Thing();
			
			System.out.println("After creating objects count is "+Thing.count);
			System.out.println("After creating objects second thing id is "+thing2.id);
			
			thing1.name = "Bob";
			thing2.name = "Sue";
			
			System.out.println(thing1.name);
			System.out.println(thing2.name);
			
			thing1.showName();
			thing2.showName();
		
			System.out.println(Math.PI); 
			//MESELA PI BIR CONSTANT THIS MEANS IT IS UNCHANGEABLE. 
			
			System.out.println(Thing.LUCKY_NUMBER);
					
		
	}
	

}
