package eNUM;

public class Enum {
	
	//public static final int DOG=0;
	//public static final int CAT=1;
	//public static final int MOUSE=2;
	
	
	public static void main(String[] args)
	{
		//int animal = CAT;
		Animal animal = Animal.CAT;
		switch(animal){
		case CAT:
			System.out.println("cat");
			break;
		case DOG:
			System.out.println("dog");
			break;
		case MOUSE:
			break;
		default:
			break;
		/*case DOG:
			System.out.println("DOG");
			break;
		case CAT:
			System.out.println("CAT");
			break;
		case MOUSE:
			System.out.println("MOUSE");
			break;*/
	
		}
		
		System.out.println(Animal.DOG);
		System.out.println(Animal.DOG.getClass());
		//System.out.println(Animal.DOG instanceof Enum);
		System.out.println(Animal.MOUSE.getName());
		System.out.println("Enum name as a string: " + Animal.DOG.name());
		
		Animal animal2 = Animal.valueOf("CAT");
		System.out.println(animal2);
		
		
	}

}
