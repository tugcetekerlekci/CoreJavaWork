
public class Grass extends Plant {

	public Grass(){
	
		System.out.println(this.height);
	}


}
