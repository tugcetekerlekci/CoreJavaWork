
public class Oak extends Plant {

	public Oak(){
		
		//This works because size is protected and Oak is a subclass of Plant. 
		this.size = "large";
		
	}
	
	

}
