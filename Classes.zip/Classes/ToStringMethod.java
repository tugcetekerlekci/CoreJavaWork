package Classes;


class Fog{
	
	public String name; 
	private int id;
	
	public Fog(int id,String name)
	{
		this.id=id;
		this.name=name;
		
	}
	
	public String toString()
	{
		//return id + ": " + name;
		
		StringBuilder sb = new StringBuilder();
		sb.append(id).append(": ").append(name);
		return sb.toString(); //this toString is for converting the StringBuilder to String! 
		
	
	}
	
	
	
}


public class ToStringMethod {
	
	public static void main(String[] args)
	{
		Fog frog1 = new Fog(6,"Tugci "+ "");
		
		Fog frog2 = new Fog(3,"Batu" + "");
		
		System.out.println(frog1);
		//bu methodu cagirdiginda otomatik olarak toString fonksiyonunu override edilip edilmedigine bakar. 
		//eger override edildiyse icindeki seyleri yazar. edilmediyse, classin adini ve hashcodeu yazar.
		//
		System.out.println(frog2);
		//tries to invoke toString method to get the String representation of the object. 
		//if you dont have this method on the object. what happens you you get class name and the hashcode:.
		//hashcode: unique identifier for your objects in Java.
		
	}

}
