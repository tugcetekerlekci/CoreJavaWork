package innerClass;

//inner class: classin icinde bi tane fonksiyonun icinde tanimlamalisin yoksa olusmuyor. 
//static inner class: works like normal class, you do not need to instantiate it in the class.
//you can think static inner class as subgroup of the class. 

public class Robot {
	
	private int id ;
	
	//generally inner classes became private. 
	//nonstatic inner classes are used you need to group together some functionality. 
	public class Brain{
		
		public void think()
		{
			System.out.println("Robot " + id + " is thinking!");
		}	
	}
	//grpuing classes 
	//you got robots, they can have interchangable battery.So you might want to create a battery
	//outside of this class and then pass it to whatever robots need that charge battery. 
	//STATIC INNER CLASEES
	//are used basically, like normal class 
	//without instantiating the outer class, using other static members.
	static class Battery{
		
		public void charge()
		{
			System.out.println("Battery is charging!..");
			
		}
		
	}

	public Robot(int id) {
		super();
		this.id = id;
	} 
	
	public void start()
	{
		System.out.println("Starting robot " +id);
		
		Brain brain = new Brain();
		brain.think();
		
	
	
	final String name = "Tugce";
	
	class Temp{
		
		public void doSomething(){
				
			System.out.println("ID is " + id);
			System.out.println("My name is " + name);
		}
	
	}
	
	Temp temp1 = new Temp();
	temp1.doSomething();
	
	
	
	}
}
