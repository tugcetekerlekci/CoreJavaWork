package Polymorhism;

public class Tree extends Plant {
	
public void grow(){
		
		System.out.println("Tree growing");
		
	}

public void shedLeaves()
{
	System.out.println("shed leaves method for tree");
	
}


}
