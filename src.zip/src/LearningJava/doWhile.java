package LearningJava;

import java.util.Scanner;

public class doWhile {
	
	public static void main (String[] args)
	{
			 
			Scanner input = new Scanner(System.in);
			/*
			 System.out.println("Enter a value  ");
			 
			 int value = input.nextInt();
			 
			 while(value !=5)
			 {
				 System.out.println("Enter a value  ");
				 value = input.nextInt();
				 
			 }*/
			 int value;
			
			do{
				
				System.out.println("Enter a value  ");
				value = input.nextInt();
				
				
			}
			while(value !=5);
			
			System.out.println("GOT 5!  ");
			
			
		
		
	}
	

}
