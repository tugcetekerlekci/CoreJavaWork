package Classes;




//String are immutable; 
public class StringBuilderAndStringFormatting {

	public static void main(String[] args)
		{
		 	
			String info = "";
			info+= "My name is Bob"; //creating a new string from the empty string and this test and then reassigning it to old String
			info+= " ";
			info+= "I am a builder";
			//not changing the original string; you're creating a new string and assigning it to old string. which is inefficient
			
			System.out.println(info);
			// if it is a big program; it slows down the performance and covers a lot of memory.
			
			StringBuilder sb = new StringBuilder("");
			sb.append("My name is Sue");
			sb.append(" ");
			sb.append("I am 23 years old."); 
			//string builder modifies the string which is more efficient. 
			
			System.out.println(sb.toString());
			
			//append method returns a reference to the stringbuilder object itself. 
			//chaining methods because all returns a reference for this.
			StringBuilder s = new StringBuilder();
			s.append("My name is Batu").append(" ").append(" I am a surfer");
			System.out.println(s);
			
			//Stringbuffer: threadsafe version of Stringbuilder. 
			//safe to access from multiple threads. 
			
			// FORMATTING /////////////////////////
			System.out.print("Here is some text.\tThat was a tab .\nThat was a new line. ");
			System.out.println("More text is here");
			
			System.out.printf("Total cost %d %n",5); //this means number
			System.out.printf("Total cost is %2d quantity is %d",5,20);
			
			for(int i=0;i<20;i++)
			{
				System.out.printf("%2d: some text here\n",i);
			}
			
			//Formatting floating point value 
			//Round up
			System.out.printf("Total value: %.2f\n", 5.688);
			System.out.printf("Total value: %.10f\n", 5.665);
			
		
			
		
		}
	
	

}
