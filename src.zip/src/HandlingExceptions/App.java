package HandlingExceptions;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;

public class App {
	
public static void main (String [] args){
		
		Test test = new Test() ; 
		
		
		/*try {
			test.run();
		} catch (ParseException | IOException e) {
			System.out.println("could not parse command file...");
		}*/
		
		/*
		try {
			test.run();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		//FilenotFoundException is an IOException for this reason, you should write filenotfound first. because,
		// FilenotFoundException is an io exception and if you write first io exception , it never goes FilenotFoundException
		//bu yuzden tersten yazarsan hata verir. 
		// java works like blocks according to the order. 
		//if you got child exception, you gonna handle that first before parent because otherwise parent exception would catch it 
		//due to polymorphism... 
		try {
			test.input();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// buradada mesela filenot u hic yazmiyor cunku o zaten bi io exception.... 
		try {
			test.input();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 		
	}

}
