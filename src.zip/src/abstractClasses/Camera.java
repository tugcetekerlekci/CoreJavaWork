package abstractClasses;

public class Camera extends Machine{

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("this is the camera");
		
	}

	@Override
	public void doStuff() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void shutDown() {
		// TODO Auto-generated method stub
		
	}

}
