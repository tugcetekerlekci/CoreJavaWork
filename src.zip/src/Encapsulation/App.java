package Encapsulation;

/*Encapsulation is an Object Oriented Programming concept that binds together the data and 
 * functions that manipulate the data, and that keeps 
 * both safe from outside interference and misuse. Data encapsulation 
 * led to the important OOP concept of data hiding.
 * your instance variable should bee always private. you stuck people putside of class. 
 * just exposed public API woth certain methods outside of the class. 
 * */
class Plant{
	
	private String name;
	public int age;
	public static final int ID = 7; // FINAL MEANS THIS CANT BE CHANGED. 
	public String getData(){
		String data="Some stuff"+ calculateGrowthForecast();
		
		return data;
		
	}

	private int calculateGrowthForecast()
	{
		return 9;
		
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
}

public class App{
	
	public static void main(String[] args)
	{
		Plant p1=new Plant();
		p1.setName("Ali");
		System.out.println(p1.getName());
		
		
	}
	

}
