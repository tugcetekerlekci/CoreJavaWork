package Classes;


class Machine{
	
		String name;
		
	
		public Machine()
		{
			this("Arnie"); //bunu yaparak ikinci constructor i cagiriyorsun. 
			
		}
		public Machine(String name)
		{
			System.out.println("Second Constructor running");
			this.name=name;
			
			
		}
		
		
	
	
}

public class Constructors {
	
	public static void main(String[] args)
	{
		Machine newMachine = new Machine();
		
		new Machine(); //illa biseye atamana gerek yok. 
		
		new Machine("Fridge");
		
		
	}

}
