
public class PlantMain {
	
	public static void main(String[] args)
	{
		Plant plant = new Plant("Tugce");
		System.out.println(plant.name);
		
		System.out.println(plant.ID);
		
	}

}
