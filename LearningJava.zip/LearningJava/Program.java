package LearningJava;

import java.util.Scanner;

public class Program {

	public static void main (String [] args){
		//create scanner object
		Scanner input = new Scanner(System.in);
		
		//output the prompt
		System.out.println("Enter a floating point value");
		
		//wait for the user to enter a line of text
		double line = input.nextDouble();
		
		//tell me what they entered 
		System.out.println("you entered  " + line);
				
	
		
		
		
	}

}
