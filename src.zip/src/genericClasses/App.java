package genericClasses;

import java.util.ArrayList;
import java.util.HashMap;

//GENERIC: A CLASS CAN WORK WITH OTHER OBJECTS. 

class Animal{
	
	
	
}

public class App {
	
	public static void main (String[] args)
	{
		//manages arrays internally. 
		//before java5 
		ArrayList list = new ArrayList();
		list.add("Apple");
		list.add("Orange");
		list.add("Banana");
		
		String fruit = (String)list.get(1);
		System.out.println(fruit);
		
		///////////////// MODERN STYLE ////////////////
		
		ArrayList<String> strings = new ArrayList<String>();
		strings.add("cat");
		strings.add("dog");
		strings.add("alligator");
		
		String animal = strings.get(1);
		System.out.println(animal);
		
		////////////THERE CAN BE MORE THAN ONE TYPE ARGUMENT ////////////
		HashMap<Integer,String> map= new HashMap<Integer,String>();
		
		///////// Java 7 Style ///////////
		ArrayList<Animal> someList = new ArrayList<>();
		
		
		
		
		
		
		
	}

}
