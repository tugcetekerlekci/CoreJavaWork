package TheTransientKeyword;

import java.io.Serializable;

//there is one same data for every object.
//there is gonna be one actual static data for all objects for Person class. 
//everyobject sees the same field/

public class Person implements Serializable {
	
	
	//serialization work witohut that. 
	//just to make sure you're using the same version of the class.. 
	
	private static final long serialVersionUID = 1947897774609305592L;
	private transient int id; 
	private String name;
	
	public Person()
	{
		System.out.println("Defult constructor.");
		
		
	}
	

	
	//static fields are not serialized because there is no reason to reailize static field.
	//it would not make sense that saving this value for everyobject because it is same for 
	//all objects in one class. it belongs to class. 
	private static int count;
	

	public static int getCount() {
		return count;
	}
	public static void setCount(int count) {
		Person.count = count;
	}
	public Person(int id, String name) {
		super();
		this.id = id;
		this.name = name;
		
		System.out.println("two args constructor.");
	}
	
	
	
	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + "]" + "Count is " +count;
	}
	
	
	
	

}
