package LearningJava;

public class Arrays {
	
	public static void main(String[] args)
	{
		int value= 7; //int is an primitive type while writing it small letters in java.
		int [] values; //creating a label, a reference variable 
		values = new int[3]; //give all values 0 as a default
		
		values[0]=10;
		
		System.out.println(values[0]);
		
		int [] numbers = {5,6,7};
		for (int i =0 ; i<numbers.length ; i++)
		{
			System.out.println(numbers[i]);
			
		}
	
		
	}

}
