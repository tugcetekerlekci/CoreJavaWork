package runTimeVsCheckedExceptions;

public class App {

	//Unchecked exceptions: not force to handle. these are called also as RUNTIME exceptions. 
	//these exceptions do not force you to handle them. which is why we do not have to put a try/catch block in here.
	//In Java, an exception is an object that wraps an error event that occurred within a method and contains: 
	//Information about the error including its type.

	public static void main (String [] args){
			try {
				Thread.sleep(111);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			int value=7; 
			//this is called runtime exception. 
			value = value/0; //it gives an exception.
			
			//Null pointer exception.
			String text=null;  // if you said test equal to null . you get a nullpointerexception. 
			//if you get nullpointerexception, you literally does not variable is not referencing anything. 
			//usually pretty simple to fix. 
			
			//System.out.println(text.length());
			
			try{
			String[] texts = {"one","two","three"};
			System.out.println(texts[3]);
			//System.out.println(texts[3]); // you get index out of bound exception. 
			}
			catch(Exception e)
			{
				System.out.println(e.toString());
				
			}
	
	}
	
}
