package Classes;
//METHOD PARAMETERS 

class Robot
{
	public void speak()
	{
		System.out.println("Hello");
	}
	//passing to the parameter to the method. 
	public void speak(String saying)
	{
		System.out.println(saying);
		
	}
	
	public void jump(int height)
	{
		System.out.println("Sam is jumping" + height + " meters");
		
	}
	
	public void move(String direction,double distance)
	{
		
		System.out.println("Sam can move " + distance + " meters to the " + direction);
	}
}

public class App {

	public static void main(String[] args)
	{
		Robot sam = new Robot();
		
		sam.speak();
		sam.speak("Hi I am Tugce");
		sam.jump(19);
		sam.move("West", 12.2);
		
		String greeting= "Hi there!";
		sam.speak(greeting);
		
	}
	
	
}
