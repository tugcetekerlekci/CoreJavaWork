package PassingByValue;

public class App {
	
	//passingbyValue :: copying the value. 
	
	
	public static void main(String[] args)
	{
		App app = new App();
		
		int value =7; 
		System.out.println("First Value is: " + value);
		
		app.show(value);
		
		System.out.println("4. Value is: " + value);
		
		/*=================================================*/
		System.out.println();
		Person person = new Person("bob");
		System.out.println("1st person is "+person);
		app.show(person);
		System.out.println("4th person is "+person);
		
		
		
	}
		
		public void show(int value)
		{
			System.out.println("2nd Value is: " + value);
			value =8;
			
			System.out.println("3rd Value is: " + value);
			
		}
		//this called method overloading. 
		public void show(Person person)
		{
			System.out.println("2nd person is "+person);
			person = new Person("mike");
			//person.setName("mike");
			System.out.println("3rd person is "+person);
			
		}
		
		
	

}
