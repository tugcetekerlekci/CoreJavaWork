package Recursion;

//towers of honoi


//heap: area of memory which is where objects were allocated using the new operator.
//stack: special area of memory, used for local variables and for remembering 
//which method called. Relatively small area for func calls and local variables. 

public class App {
	public static void main(String[] args)
	{
	
		//int value = 4; 
		//E.g 4! ; 
		calculate(4);
		//System.out.println(value);
		System.out.print(calculate(4));
		System.out.println(calculate(5));
		
		
	}
	private static int calculate(int value){
		//System.out.println(value);	
		
		if(value==1)
		{
			return 1;
		}
		
		return calculate(value-1) * value;
		
	}
	
	//recursion can cause STACKOVERFLOW ERRORS. For that reason it is better to avoid
	//recursion. 
	

}
