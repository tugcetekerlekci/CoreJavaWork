package LearningJava;

public class MultiDimensionalArrays {
	
	public static void main(String[] args)
	{
	
	int [] values = {3,5,2343};
	
	 //System.out.println(values[2]);
	 
	 int[][] grid = { {3,5,2343}, 
			 		  {2,4}, 
			 		  {3,4,6} };
	 
	 
	 System.out.println(grid[2][2]);
	 
	 String [][] text = new String[2][3];
	 
	 System.out.println(text[0][1]);
	 
	 for(int row=0; row<grid.length;row++)
	 {
		 for(int col=0; col<grid[row].length;col++)
		 {
			 System.out.println(grid[row][col] +"\t");
			 
		 }
		 
		 System.out.println();
		 
		 
	 }
	 
	 String[][] words = new String[2][];
	 
	 System.out.println(words[0]);
	 
	 words[0] = new String[3];
	 words[0][1]="hi there";
	 System.out.println(words[0][1]);
	 
	
	
	}

}
