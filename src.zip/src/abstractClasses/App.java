package abstractClasses;

//ABSTRACT CLASS IS A STRONG STATEMENT. 
//CHILD CLASS FUNDAMENTALLY EXTENDS A PARENT CLASS. 

//Abstract classes cannot be instantiated by itself. 
//the most key thing is when you're seperating interface and abstract class is 
//when you say a child class fundamentally extends a parent class, like car extends machine. 
//when you are talking about an abstract class; 
//you really make a strong statement than simply implementing an interface . you said CAR IS A MACHINE. 
//Parent class determines this fundamental identity, when you have an abstract class. 
//A class can implement many interfaces but it has also one abstract-parent class in hiyerarsi.
//you cant have an actual code in an interface. However you can actually have real functionality.
//implementations in an abstract class. 


/*abstract class: car is a machine- car has an information. 
 * abstact class is a parent class and it can be only one for each child class. However classes can have more than one interfaces
 * abstract class can include actual code the implementations. However, 
 * interface has only declarations and impleementing the methods only depends on its child classes. 
 * you cannot wrote actual code in interface. 
 * */


public class App {
	
	public static void main(String[] args)
	{
		Camera cam1 = new Camera();
		cam1.setId(5);
		
		Car car1 = new Car();
		car1.setId(4);
		
		//bunu yapamazsin 
		//Machine machine1 = new Machine();
		car1.run();
		
		
	}

}
