package anonymousclasses;

//Anonymous classes: way of either extending or existing class either implementing interface. 

class Machine
{
	public void start(){
		System.out.println("Machine started...");
		
	}
}

interface Plant{
		public void grow();
	
}

public class App {
	
	public static void main(String[] args)
	{
		/*burada yarattigin sey aslinda bi machine objesi degil cunku onun fobksiyonlarini almiyor
		 * bu yuzden anonymous class olarak geciyor.*/
		Machine machine1 = new Machine(){
			@Override public void start(){
				System.out.println("Camera snapping");
			}
			
		};
		machine1.start();
		
		Plant plant1 = new Plant(){

			@Override
			public void grow() {
				
				System.out.println("Plant is growing...");
				
			}
			
			
		};
		
		plant1.grow();
	}

}
