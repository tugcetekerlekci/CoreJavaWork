package ocean;

public class Seaweed {

}
