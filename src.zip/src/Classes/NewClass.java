package Classes;

class Person {
	
		String name;
		int age;
		
		void speak()
		{
			System.out.println("My name is " + name + " and I am " + age + " years old");
			
			
		}
		
		int yearstoRetirement()
		{
			int yearsLeft = 65-age;
			
			//System.out.print(yearsLeft);
			
			return yearsLeft;
			
			
		}
		
		int getAge()
		{
			
			return age;
			
		}
		
		String getName()
		{
			return name;
			
		}
	
	
}


public class NewClass {

	public static void main(String[] args)
	{
		Person person1= new Person();
		
		person1.name="Tugce Tekerlekci";
		person1.age=34;
		person1.speak();
		
		System.out.println(person1.name);
		
		System.out.print("Years for retirement is "+person1.yearstoRetirement());
		System.out.print("\n");
		
		int age = person1.getAge();
		
		String name = person1.getName();
		
		System.out.print("Name is "+ name);
		System.out.print("\n");
		System.out.print("Age is "+ age);
		
		
		
	}
	
	
	



}
