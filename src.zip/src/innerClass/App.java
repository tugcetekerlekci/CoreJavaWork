package innerClass;

public class App {

	public static void main(String[] args)
	{
		Robot robot = new Robot(7);
	
		robot.start();
		
		Robot.Brain brain = robot.new Brain();
		brain.think();
		
		//you can robot.battery, robot.cpu but the point is its gropued with ROBOT. 
		//Other than that, it is like normal class.
		Robot.Battery battery = new Robot.Battery();
		
		battery.charge();
	
		
	}
	
}
