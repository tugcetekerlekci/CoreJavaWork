package abstractClasses;

public class Car extends Machine {

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("this is the car");
		
	}

	@Override
	public void doStuff() {
		// TODO Auto-generated method stub
		System.out.println("Do Stuff");
	}

	@Override
	public void shutDown() {
		// TODO Auto-generated method stub
		System.out.println("Shut Down");
		
	}

}
